import type { QuizStem } from "../quizData";

export const PSY_STEMS: QuizStem[] = [
  {
    id: "PSY-001",
    questionNumber: "MEQ-076",
    topic: "psychotherapy",
    difficulty: "consultant",
    title: "Splitting and chronic suicidality on an inpatient unit",
    candidateRole: "Consultant psychiatrist, acute inpatient unit",
    setting: "Metropolitan acute psychiatric inpatient ward",
    stem: `You are the consultant psychiatrist on an acute inpatient unit.

Alicia is a 29-year-old woman with a diagnosis of borderline personality disorder, recurrent non-suicidal self-injury, trauma history, and multiple previous admissions. She was admitted voluntarily five days ago after telling the crisis team she would overdose if left alone. Since admission, she has formed a close relationship with one junior nurse and refuses to speak to other staff, saying, "She is the only one who actually cares whether I live or die."

Over the weekend, Alicia cut her forearm superficially after being told that leave would not be approved. She then told the night registrar, "If you discharge me, my blood is on your hands." The registrar extended admission and placed her on constant observations. The nursing team is now divided: some staff feel she is "too risky to discharge," while others say the admission is "just reinforcing her behaviour."

The bed manager is requesting discharge because three people are waiting in ED. Alicia's mother rings the ward repeatedly, saying, "Every time you send her home she gets worse." The treating psychologist says prolonged admission may undermine the community DBT plan. The junior registrar asks you whether the safest option is to keep Alicia admitted until she denies suicidal thoughts.`,
    totalMarks: 22,
    signals: [
      {
        id: "s1",
        name: "Chronic suicidality versus acute escalation",
        category: "risk_self",
        severity: "critical",
        clueInStem: "If you discharge me, my blood is on your hands.",
        whyItMatters: "A consultant must distinguish chronic baseline risk from acute dynamic escalation, otherwise admission decisions become reactive and reinforce maladaptive patterns.",
        modelWording: "Differentiate Alicia's chronic suicide risk from acute dynamic escalation by assessing intent, planning, means, intoxication and recent loss of supports — discharge must be based on dynamic risk, not threats alone.",
        keywords: ["chronic suicidality", "dynamic risk", "acute escalation", "baseline risk", "discharge planning", "distinguish"],
      },
      {
        id: "s2",
        name: "Splitting within the inpatient team",
        category: "mdt_conflict",
        severity: "critical",
        clueInStem: "She is the only one who actually cares whether I live or die.",
        whyItMatters: "Idealisation of one nurse and devaluation of others divides the team, creates inconsistent care, and increases coercive or rejecting responses that worsen outcomes.",
        modelWording: "Recognise splitting and idealisation as BPD phenomena dividing the team — provide consultant leadership with a unified plan, consistent boundaries and consistent language across all staff.",
        keywords: ["splitting", "idealisation", "team division", "consistent boundaries", "unified care plan", "BPD"],
      },
      {
        id: "s3",
        name: "Iatrogenic risk of prolonged admission",
        category: "ethics",
        severity: "important",
        clueInStem: "prolonged admission may undermine the community DBT plan.",
        whyItMatters: "Inpatient care may reduce immediate anxiety but worsen dependency, avoidance and loss of community treatment momentum — admission can be harmful if prolonged beyond its clinical purpose.",
        modelWording: "Consider whether continued admission is iatrogenic by reinforcing dependency and undermining the DBT-based community recovery plan — brief admission with clear goals is preferable to open-ended containment.",
        keywords: ["iatrogenic admission", "dependency", "DBT", "least restrictive", "therapeutic frame", "prolonged"],
      },
      {
        id: "s4",
        name: "Staff therapeutic nihilism and countertransference",
        category: "mdt_conflict",
        severity: "important",
        clueInStem: "just reinforcing her behaviour.",
        whyItMatters: "Dismissive framing of BPD increases invalidation, staff burnout and countertransference-driven unsafe decision-making.",
        modelWording: "Address staff countertransference and therapeutic nihilism directly — validate staff frustration while reframing self-harm as communication and distress, not manipulation.",
        keywords: ["countertransference", "therapeutic nihilism", "validation", "staff burnout", "behavioural limits", "reframe"],
      },
      {
        id: "s5",
        name: "Family anxiety reinforcing admission pressure",
        category: "family_carer",
        severity: "important",
        clueInStem: "Every time you send her home she gets worse.",
        whyItMatters: "Family fear escalates pressure for ongoing admission and may obscure collaborative safety planning — family psychoeducation about chronic risk is essential.",
        modelWording: "Engage Alicia's mother to validate concern, explain chronic risk formulation, and include family in a realistic safety and crisis plan rather than using family anxiety to drive admission decisions.",
        keywords: ["family anxiety", "carer involvement", "safety plan", "psychoeducation", "chronic risk", "mother"],
      },
      {
        id: "s6",
        name: "Bed pressure as unsafe primary driver",
        category: "system_pressure",
        severity: "optional",
        clueInStem: "three people are waiting in ED.",
        whyItMatters: "Bed pressure is a real system constraint but must not become the clinical rationale for discharge — the decision must be clinically defensible and documented as such.",
        modelWording: "Acknowledge bed pressure but ensure discharge is clinically justified, documented with risk reasoning, and linked to a safe community plan — not driven by access block.",
        keywords: ["bed pressure", "clinical rationale", "safe discharge", "documentation", "system pressure", "access block"],
      },
    ],
    priorityOrder: {
      urgent: ["s1", "s2"],
      secondary: ["s3", "s4", "s5"],
      lowYield: ["s6"],
    },
    modelAnswer: `Review Alicia directly and formulate risk as chronic baseline versus acute dynamic escalation — threats alone do not determine admission length.

Assess current suicide risk: intent, plan, means, recent escalation, intoxication, mental state change, and ability to collaborate with a safety plan.

Recognise splitting and team division. Hold an urgent MDT meeting: agree consistent language, clarify observation rationale, define leave and discharge criteria, support junior staff, and stop special arrangements through one nurse.

Address therapeutic nihilism: validate staff frustration, reframe self-harm as communication and distress regulation, not manipulation.

Consider iatrogenic effects of prolonged admission: dependency, reinforcement of crisis behaviour, disruption of DBT plan. Brief admission with clear goals is preferable.

Liaise with community DBT and crisis team to create a step-down plan with brief admission goals, crisis plan, follow-up appointment, means restriction and after-hours pathway.

Involve mother with consent: explain chronic risk formulation and clarify that indefinite admission does not eliminate risk.

Document: acute and chronic risk formulation, MDT consensus, rationale for observations, family communication, contingency plan.`,
  },
  {
    id: "PSY-002",
    questionNumber: "MEQ-077",
    topic: "psychotherapy",
    difficulty: "consultant",
    title: "Dependency and failed engagement in community BPD care",
    candidateRole: "Consultant psychiatrist, community mental health team",
    setting: "Urban community mental health service",
    stem: `You are the consultant psychiatrist supervising a community mental health team.

Nathan is a 35-year-old man with borderline personality disorder, alcohol misuse, childhood trauma and repeated crisis presentations. He has missed four psychology appointments but sends multiple late-night emails to his care coordinator saying, "You are the only person stopping me from ending it." When the care coordinator does not respond immediately, Nathan presents to ED stating he has been abandoned by the team.

The care coordinator feels overwhelmed and says she is receiving emails on her personal phone. A junior registrar suggests discharging Nathan from the service because "he is not engaging." The psychologist is reluctant to offer therapy until Nathan is more stable and abstinent from alcohol. Nathan's GP says he is prescribing diazepam "because the mental health team won't help him."

At review, Nathan says, "If you put limits on contact, that proves you don't care." He denies current suicidal intent but says he may drink and cut himself if left alone. The team asks you to decide whether to close his file, increase contact, or refer him back to ED-based crisis care.`,
    totalMarks: 22,
    signals: [
      {
        id: "s1",
        name: "Engagement failure as clinical data not non-compliance",
        category: "diagnosis_formulation",
        severity: "critical",
        clueInStem: "he is not engaging.",
        whyItMatters: "Discharging for non-attendance without formulation repeats abandonment and increases crisis use — missed appointments in BPD are attachment behaviour, not simple non-compliance.",
        modelWording: "Formulate missed appointments and crisis contact as attachment insecurity and affect dysregulation — this is clinical data requiring formulation, not grounds for discharge.",
        keywords: ["engagement failure", "attachment insecurity", "non-attendance", "formulation", "abandonment", "not non-compliance"],
      },
      {
        id: "s2",
        name: "Boundary diffusion and unsafe clinician dependency",
        category: "ethics",
        severity: "critical",
        clueInStem: "You are the only person stopping me from ending it.",
        whyItMatters: "Over-reliance on one clinician with personal phone contact increases risk, causes burnout and creates inconsistent care — this is a clinical governance issue not just a personal boundary issue.",
        modelWording: "Address dependency on the care coordinator by shifting to team-based boundaried care — stop personal phone contact, document communication boundaries, and prevent single-clinician rescue dynamics.",
        keywords: ["dependency", "boundary setting", "care coordinator", "team-based care", "rescue dynamic", "personal phone"],
      },
      {
        id: "s3",
        name: "Personal phone contact — governance and staff safety",
        category: "governance",
        severity: "important",
        clueInStem: "receiving emails on her personal phone.",
        whyItMatters: "Personal phone contact bypasses governance, creates unsafe expectations, exposes staff to burnout and creates medico-legal risk for the clinician and service.",
        modelWording: "Stop personal phone contact immediately and establish documented service-based communication boundaries — this is a governance issue requiring formal resolution, not a personal preference.",
        keywords: ["personal phone", "professional boundaries", "staff safety", "communication plan", "governance", "medico-legal"],
      },
      {
        id: "s4",
        name: "Diazepam prescribing by GP — overdose and disinhibition risk",
        category: "risk_self",
        severity: "important",
        clueInStem: "prescribing diazepam because the mental health team won't help him.",
        whyItMatters: "Diazepam in a man with BPD and alcohol misuse increases overdose risk, disinhibition and dependency — the GP's prescribing reflects a system failure requiring urgent liaison.",
        modelWording: "Liaise urgently with the GP to rationalise diazepam — overdose risk, alcohol interaction, disinhibition and dependence make benzodiazepines high-risk in this presentation.",
        keywords: ["diazepam", "alcohol misuse", "disinhibition", "overdose risk", "GP liaison", "benzodiazepine"],
      },
      {
        id: "s5",
        name: "Conditional threats around limits — validate and hold",
        category: "risk_self",
        severity: "important",
        clueInStem: "If you put limits on contact, that proves you don't care.",
        whyItMatters: "Threats conditional on limit-setting must not coerce unstructured care — they require validation of the underlying fear with consistent maintenance of boundaries.",
        modelWording: "Respond to conditional threats with validation and consistent limits — explain that predictable boundaries are part of safe care, not rejection, and that limits protect the therapeutic relationship.",
        keywords: ["conditional threats", "limits", "validation", "boundaries", "safe care", "not rejection"],
      },
      {
        id: "s6",
        name: "Therapy access blocked by stability requirement",
        category: "system_pressure",
        severity: "optional",
        clueInStem: "reluctant to offer therapy until Nathan is more stable",
        whyItMatters: "Requiring complete stability before therapy access indefinitely excludes the most unwell patients from evidence-based treatment.",
        modelWording: "Consider staged therapy engagement with clear expectations rather than requiring complete stability — waiting for perfect conditions before offering DBT may never resolve.",
        keywords: ["staged therapy", "DBT", "therapy access", "stabilisation", "evidence-based", "not waiting"],
      },
    ],
    priorityOrder: {
      urgent: ["s1", "s2"],
      secondary: ["s3", "s4", "s5"],
      lowYield: ["s6"],
    },
    modelAnswer: `Do not frame this as non-engagement. Formulate missed appointments, crisis emails and ED presentations as attachment insecurity and affect dysregulation — this is clinical data, not grounds for discharge.

Assess current risk: suicidal intent, recent self-harm, alcohol use, access to means, escalation from baseline, capacity to use crisis plan.

Address dependency on one clinician: move to team-based care, stop personal phone contact immediately, document communication boundaries, provide predictable response times. This is a governance issue.

Support and supervise the care coordinator: validate burden, address boundary diffusion, prevent burnout, ensure no single clinician carries risk alone.

Create a structured care plan: scheduled appointments, crisis plan, clear limits on emails and calls, ED use only for acute risk, written formulation shared with team.

Liaise with GP urgently regarding diazepam — overdose risk, alcohol interaction and disinhibition make this high-risk.

Engage Nathan directly: validate distress, explain boundaries as safety not rejection, clarify what the service can and cannot provide.

Do not discharge abruptly for non-attendance — this repeats abandonment and increases acute risk.`,
  },
  {
    id: "PSY-003",
    questionNumber: "MEQ-078",
    topic: "psychotherapy",
    difficulty: "consultant",
    title: "Chronic NSSI, ED access block and therapeutic nihilism",
    candidateRole: "Consultant psychiatrist, emergency psychiatry service",
    setting: "Busy metropolitan emergency department, Friday evening",
    stem: `You are the consultant psychiatrist covering a busy metropolitan emergency department on a Friday evening.

Jordan is a 26-year-old non-binary person with complex trauma, borderline personality disorder and chronic non-suicidal self-injury. They present after cutting their thigh with a razor following an argument with their partner. The wound requires suturing but is not life-threatening. Jordan says, "Cutting is the only way I stop myself from doing something worse."

Jordan has presented to ED twelve times in the past three months. The ED consultant says, "We can't keep admitting them every time they cut." A psychiatry registrar says Jordan is "low risk because it's superficial." The mental health nurse says staff are frustrated because Jordan often refuses discharge plans but later complains that nobody helps.

Jordan says, "If you send me home tonight, I'll just cut deeper." There are no psychiatric beds available, and the ED executive is calling hourly about mental health access block. Jordan's partner is in the waiting room and says they are exhausted and cannot provide supervision tonight.`,
    totalMarks: 22,
    signals: [
      {
        id: "s1",
        name: "Chronic NSSI with possible acute escalation — not the same risk",
        category: "risk_self",
        severity: "critical",
        clueInStem: "If you send me home tonight, I'll just cut deeper.",
        whyItMatters: "A consultant must distinguish chronic baseline NSSI from acute escalation in lethality, intent, distress and supports — Jordan's statement about cutting deeper may indicate escalation requiring different management.",
        modelWording: "Differentiate chronic NSSI from acute escalation by assessing intent, lethality, intoxication, distress level, access to means and available supports tonight — do not assume chronic pattern means static risk.",
        keywords: ["chronic NSSI", "acute escalation", "lethality", "dynamic risk", "self-harm", "deeper", "distinguish"],
      },
      {
        id: "s2",
        name: "Therapeutic nihilism — invalidating and clinically unsafe",
        category: "mdt_conflict",
        severity: "critical",
        clueInStem: "We can't keep admitting them every time they cut.",
        whyItMatters: "Therapeutic nihilism in ED toward BPD patients directly increases invalidation, worsens outcomes and leads to unsafe premature discharge driven by frustration rather than clinical assessment.",
        modelWording: "Address therapeutic nihilism in the ED team directly — validate staff frustration while challenging dismissive language and ensuring clinical decisions are based on formulation not exasperation.",
        keywords: ["therapeutic nihilism", "invalidation", "staff frustration", "BPD", "dismissive", "premature discharge"],
      },
      {
        id: "s3",
        name: "Superficial wound does not equal low risk",
        category: "risk_self",
        severity: "important",
        clueInStem: "low risk because it's superficial.",
        whyItMatters: "Wound depth is a poor proxy for suicide risk — intent, escalation pattern, intoxication and loss of protective factors determine risk, not wound severity.",
        modelWording: "Do not use wound superficiality as a risk proxy — assess intent, function of self-harm, escalation from baseline, intoxication and protective capacity tonight.",
        keywords: ["superficial", "wound severity", "risk formulation", "intent", "function of self-harm", "poor proxy"],
      },
      {
        id: "s4",
        name: "Self-harm as affect regulation — understand the function",
        category: "diagnosis_formulation",
        severity: "important",
        clueInStem: "Cutting is the only way I stop myself from doing something worse.",
        whyItMatters: "Understanding self-harm as affect regulation guides crisis intervention and alternatives — Jordan is telling you cutting prevents something worse, which is clinically important information.",
        modelWording: "Explore the function of self-harm as affect regulation and identify what Jordan fears doing instead — this is the target for safety planning and distress tolerance alternatives.",
        keywords: ["affect regulation", "coping strategy", "function of self-harm", "distress tolerance", "safety planning", "worse"],
      },
      {
        id: "s5",
        name: "Partner burnout — discharge plan cannot rely on unavailable supervision",
        category: "family_carer",
        severity: "important",
        clueInStem: "cannot provide supervision tonight.",
        whyItMatters: "A discharge plan requiring supervision from an exhausted partner who has stated they cannot provide it tonight is not a safe discharge plan.",
        modelWording: "Assess partner burnout and do not build a discharge plan dependent on supervision the partner has explicitly said they cannot provide tonight.",
        keywords: ["carer burnout", "partner supervision", "discharge safety", "unavailable", "exhausted", "cannot provide"],
      },
      {
        id: "s6",
        name: "Executive pressure — document clinical reasoning independently",
        category: "system_pressure",
        severity: "optional",
        clueInStem: "calling hourly about mental health access block.",
        whyItMatters: "Executive pressure about access block is a real system constraint but cannot override individual clinical risk formulation — the consultant must document defensible clinical reasoning.",
        modelWording: "Acknowledge access block while documenting a clinically defensible, least restrictive disposition plan — executive pressure is relevant context, not a clinical reason for discharge.",
        keywords: ["access block", "bed pressure", "executive pressure", "defensible decision", "least restrictive", "document"],
      },
    ],
    priorityOrder: {
      urgent: ["s1", "s2"],
      secondary: ["s3", "s4", "s5"],
      lowYield: ["s6"],
    },
    modelAnswer: `Review Jordan directly. Do not accept the registrar's low-risk assessment based on wound superficiality — wound depth is not a risk proxy.

Assess acute-on-chronic risk: intent, escalation from baseline, intoxication, access to razors tonight, ability to collaborate, reasons for living, and what Jordan means by "something worse."

Understand the function of self-harm: Jordan is telling you cutting prevents something worse — this is the target for safety planning, not just wound management.

Address therapeutic nihilism in ED staff: validate frustration, challenge dismissive language, reframe care as structured and boundaried rather than reflexively admitting or rejecting.

Do not build a discharge plan around partner supervision — the partner has stated they cannot provide it tonight.

Develop a brief crisis intervention: wound care, remove access to razors, distress tolerance alternatives, written safety plan with specific crisis contacts, clear return criteria.

Consider short-stay or crisis stabilisation if acute risk cannot be safely managed at home without supervision and no inpatient bed is available.

Manage system pressure: escalate access block issues through appropriate channels, document clinical reasoning independently of executive pressure.`,
  },
];
